+++
author = "Hugo Authors"
title = "Rich Content"
date = "2019-03-10"
description = "A brief description of Hugo Shortcodes"
tags = [
    "shortcodes",
    "privacy",
]
+++

Hugo ships with several [Built-in Shortcodes](https://gohugo.io/content-management/shortcodes/#use-hugos-built-in-shortcodes) for rich content, along with a [Privacy Config](https://gohugo.io/about/hugo-and-gdpr/) and a set of Simple Shortcodes that enable static and no-JS versions of various social media embeds.
<!--more-->


## YouTube Privacy Enhanced Shortcode

{{< youtube ZJthWmvUzzc >}}

<br>


## Twitter Shortcode

{{< x id="1085870671291310081" user="SanDiegoZoo" >}}

<br>



## Vimeo Shortcode

{{< vimeo 48912912 >}}
